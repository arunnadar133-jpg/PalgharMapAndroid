plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("com.google.gms.google-services") }
android { namespace="com.palgharmap.app"; compileSdk=37
 defaultConfig { applicationId="com.palgharmap.app"; minSdk=26; targetSdk=37; versionCode=1; versionName="1.0" }
}
dependencies {
 implementation("androidx.core:core-ktx:1.17.0")
 implementation("androidx.appcompat:appcompat:1.7.1")
 implementation("androidx.webkit:webkit:1.14.0")
 implementation(platform("com.google.firebase:firebase-bom:34.19.0"))
 implementation("com.google.firebase:firebase-auth")
}
