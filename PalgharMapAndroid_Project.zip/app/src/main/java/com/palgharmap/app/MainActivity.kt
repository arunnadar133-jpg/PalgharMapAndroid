package com.palgharmap.app
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.Firebase
import com.google.firebase.auth.*
import java.util.concurrent.TimeUnit

class MainActivity: AppCompatActivity() {
 private lateinit var w: WebView; private lateinit var auth: FirebaseAuth; private var id:String?=null
 override fun onCreate(b:Bundle?){super.onCreate(b);auth=Firebase.auth;w=WebView(this);w.settings.javaScriptEnabled=true;w.settings.domStorageEnabled=true;w.webViewClient=WebViewClient();w.addJavascriptInterface(Bridge(),"AndroidAuth");w.loadUrl("file:///android_asset/index.html");setContentView(w)}
 inner class Bridge {
  @JavascriptInterface fun sendOtp(p:String){runOnUiThread{
   val n=if(p.startsWith("+"))p else "+91$p"
   val o=PhoneAuthOptions.newBuilder(auth).setPhoneNumber(n).setTimeout(60L,TimeUnit.SECONDS).setActivity(this@MainActivity)
   .setCallbacks(object:PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
    override fun onVerificationCompleted(c:PhoneAuthCredential){auth.signInWithCredential(c).addOnCompleteListener{w.evaluateJavascript("nativeLoginSuccess()",null)}}
    override fun onVerificationFailed(e:Exception){w.evaluateJavascript("nativeOtpError("+org.json.JSONObject.quote(e.message?:"OTP failed")+")",null)}
    override fun onCodeSent(v:String,t:PhoneAuthProvider.ForceResendingToken){id=v;w.evaluateJavascript("nativeOtpSent()",null)}
   }).build();PhoneAuthProvider.verifyPhoneNumber(o)
  }}
  @JavascriptInterface fun verifyOtp(c:String){val v=id;if(v==null)return;auth.signInWithCredential(PhoneAuthProvider.getCredential(v,c)).addOnCompleteListener{if(it.isSuccessful)w.evaluateJavascript("nativeLoginSuccess()",null)else w.evaluateJavascript("nativeOtpError('OTP गलत है')",null)}}
 }
}