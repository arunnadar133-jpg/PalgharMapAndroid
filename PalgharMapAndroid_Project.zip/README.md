# Palghar Map Android

Package: `com.palgharmap.app`

Firebase config is included in `app/google-services.json`.

Build requires JDK 17, Android SDK 37 and Gradle 9.4.1. Enable Firebase Phone Sign-in and add the build SHA-1/SHA-256 before testing real SMS OTP.
